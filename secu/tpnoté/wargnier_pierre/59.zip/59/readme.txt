text 0  chiffrement de césar    	clef 13 "N"
text 1  chiffrement de Vigénère   	clef ZHOBF
text 2  chiffrement par substitution    clef
text 3  chiffrement de Vigénère     	clef
text 4  chiffrement par substitution    clef 
text 5  chiffrement de césar    	clef 22 "W"
text 6  chiffrement de Vigénère     	clef VIOJNNMHT
text 7  chiffrement de vigénère    	clef YEPFGUHDPSHVCFKUHPLS
text 8  chiffrement par substitution    clef 
text 9  chiffrement de césar    	clef 9 "J" 


#ifndef Graphe_H
#define Graphe_H


char* concatAvecStringH(char* ch1,char* ch2);
char* concatSansStringH(char* ch1,char* ch2);
#endif

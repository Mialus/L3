#include "automate.h"
#include "liste.h"

void afficheAutomate(automate* A){
int i,j,valsize;
liste* transAct;

printf("les états initiaux : 0\n");
printf("les états finaux : 1\n");
printf("les transitions :\n");

for(i=0;i<A->size;i++)
{
printf("---------------------------\n");
  printf("Depuis l'état %d\n", i);
    for(j=0; j<A->sizealpha;j++){
        transAct = A->trans[i][j];
        if (transAct != NULL){ //Verification si il y a bien une transition
            printf("avec la lettre %c : \n", j + 'a');
        }
        while (transAct != NULL){
        printf("	vers l'état %d \n",transAct->state);
        transAct = transAct->suiv;
	}
   }
}
}

void ajouteTransition(automate* A, int depart, int arrivee, char etiquette)
{
int i=13;
liste *l;
if(((etiquette-'a')<0)||((etiquette-'a')>26)){
return;
}
else
{
	ajouteListe(&(A->trans[depart][etiquette-'a']),arrivee);
}	
}

automate* construitAutomateExemple(){

automate* ptExemple=malloc(sizeof(automate));
int i,j;
ptExemple->size=5;
ptExemple->sizealpha=2;
ptExemple->initial=(int*) malloc(ptExemple->size*sizeof(int));
ptExemple->initial[0]=1;
ptExemple->initial[1]=1;
ptExemple->initial[2]=0;
ptExemple->initial[3]=0;
ptExemple->initial[4]=0;
ptExemple->final=(int*) malloc(ptExemple->size*sizeof(int));
ptExemple->final[0]=0;
ptExemple->final[1]=1;
ptExemple->final[2]=0;
ptExemple->final[3]=0;
ptExemple->final[4]=1;

ptExemple->trans=(liste***) malloc(ptExemple->size*sizeof(liste**));

for(i=0;i<ptExemple->size;i++){
	ptExemple->trans[i]=(liste**) malloc(ptExemple->sizealpha*sizeof(liste*));
	for(j=0;j<ptExemple->sizealpha;j++){
		ptExemple->trans[i][j]=NULL;
	}
}

ajouteTransition(ptExemple,0,1,'a');
ajouteTransition(ptExemple,0,2,'a');
ajouteTransition(ptExemple,0,3,'a');
ajouteTransition(ptExemple,2,3,'a');
ajouteTransition(ptExemple,1,3,'b');
ajouteTransition(ptExemple,3,3,'b');
ajouteTransition(ptExemple,3,4,'b');
ajouteTransition(ptExemple,4,4,'a');
ajouteTransition(ptExemple,2,4,'b');
afficheAutomate(ptExemple);

return ptExemple;
}


int compteTransition(automate* A){
int nbtransi=0;
int i,j;
liste* transAct;

for(i=0;i<A->size;i++)
{
    for(j=0; j<A->sizealpha;j++){
        transAct = A->trans[i][j];
        if (transAct != NULL){ //Verification si il y a bien une transition
	nbtransi++;
        }
        while (transAct != NULL){
        transAct = transAct->suiv;
	}
   }
}
return nbtransi;
}

int Determinisme(automate* A){
int deter=1;
int autSize=A->sizealpha;
int nbTrans,i,j;
liste* transAct;

for(i=0;i<A->size;i++)
{
    for(j=0; j<A->sizealpha;j++){
        transAct = A->trans[i][j];
	nbTrans=0;
        while (transAct != NULL){
        transAct = transAct->suiv;
	nbTrans++;
	}
	if(nbTrans>1)
	{
	deter=0;	
	}
   }
}
return deter;
}

int Complet(automate* A){
int comp=1;
int autSize=A->sizealpha;
int nbTrans,i,j;
liste* transAct;

for(i=0;i<A->size;i++)
{
    for(j=0; j<A->sizealpha;j++){
        transAct = A->trans[i][j];
	comp=0;
        while (transAct != NULL){
        transAct = transAct->suiv;
	nbTrans++;
	}
	if(nbTrans==0)
	{
	comp=0;	
	}
   }
}
return comp;
}

void supprimeTransistion(automate* A, int depart, int arrivee, char etiquette)
{
if(((etiquette-'a')<0)||((etiquette-'a')>26)){
return;
}
else
{
	supprimeListe(&(A->trans[depart][etiquette-'a']),arrivee);
}

}

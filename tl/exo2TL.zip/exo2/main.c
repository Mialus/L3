#include "chaine.h"
#include "graphe.h"
#include "automate.h"

int main()
{

automate* A=construitAutomateExemple();
//int nbtrans=compteTransition(A);
//printf("%d\n",nbtrans);
return 0;
}

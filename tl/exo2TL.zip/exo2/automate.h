#ifndef Automate_H
#define Automate_H
#include "liste.h"

typedef struct {
	int size;
	int sizealpha;
	int* initial;
	int* final;
	liste*** trans;
} automate;

void afficheAutomate(automate* A);
void ajouteTransition(automate* A, int depart, int arrivee, char etiquette);
automate* construitAutomateExemple();
int compteTransistion(automate* A);
int Determinisme(automate* A);
#endif

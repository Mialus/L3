#include "Ctriangle.h"

void Ctriangle::setBase(float x)
{

	m_base=x;
}
void Ctriangle::setHauteur(float y)
{

	m_hauteur=y;

}

float Ctriangle::getBase()
{
return m_base;
}

float Ctriangle::getHauteur()
{
return m_hauteur;

}

#include "Couverture.h"

Couverture::Couverture(): Crectangle()
{

};

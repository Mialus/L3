#ifndef CCouverture_H
#define Couverture_H
#include "Crectangle.h"

class CCouverture : public Crectangle
{
public:
	CCouverture(void);

};
#endif

#include "Cpignon.h"

Cpignon::Cpignon(): Ctriangle()
{

};

#include "Cfacade.h"


Cfacade::Cfacade()
{
m_rectangle.setLargeur(4);
m_rectangle.setHaut(4);
m_ouverture[0].setHaut(4);
m_ouverture[0].setLargeur(4);
m_pignon.setBase(4);
m_pignon.setHauteur(4);
};

#ifndef Cfacade_H
#define Cfacade_H
#include "Crectangle.h"
#include "Cpignon.h"
#include "Couverture.h"


class Cfacade
{
	public:

		Cfacade(void);
	

	protected:
 
	Crectangle m_rectangle;
 	Cpignon m_pignon;
	Couverture m_ouverture[];
};
#endif

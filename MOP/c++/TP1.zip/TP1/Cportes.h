#ifndef Cportes_H
#define Cportes_H
#include "Couverture.h"

class Cportes : public Couverture
{
public:
	Cportes	(void);
};
#endif

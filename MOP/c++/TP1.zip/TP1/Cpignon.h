#ifndef Cpignon_H
#define Cpignon_H
#include "Ctriangle.h"

class Cpignon : public Ctriangle 
{
	public:
		Cpignon(void);

};
#endif

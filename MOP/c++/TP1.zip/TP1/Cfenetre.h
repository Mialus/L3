#ifndef Cfenetre_H
#define Cfenetre_H
#include "Couverture.h"

class Cfenetre : public Couverture
{
public:
	Cfenetre(void);

};
#endif

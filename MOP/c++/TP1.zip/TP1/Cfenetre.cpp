#include "Cfenetre.h"

Cfenetre::Cfenetre(): Couverture()
{

};

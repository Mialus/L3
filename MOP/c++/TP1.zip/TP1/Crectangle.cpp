#include "Crectangle.h"

void Crectangle::setLargeur(float x)
{

	m_largeur=x;
}
void Crectangle::setHaut(float y)
{

	m_haut=y;

}

float Crectangle::getLargeur()
{
return m_largeur;
}

float Crectangle::getHaut()
{
return m_haut;
}

#include "Cportes.h"

Cportes::Cportes(): Couverture()
{

};

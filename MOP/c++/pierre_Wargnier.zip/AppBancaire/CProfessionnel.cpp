#include "CProfessionnel.h"

void CProfessionnel::setRaiSocial(char* val)
{
	rai=val;
};

void CProfessionnel::setSIRET(char* val2)
{
	sir=val2;
};

char* CProfessionnel::getRaiSocial()
{
	return rai;
};

char* CProfessionnel::getSIRET()
{
	return sir;
};

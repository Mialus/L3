#include "CEpargne.h"

void CEpargne::setSolde(float val)
{

	sol=val;

}

void CEpargne::setTaux(float val)
{

	tau=val;

}

float CEpargne::getSolde()
{
return sol;
}

float CEpargne::getTaux()
{
return tau;
}

#ifndef CCompte_H
#define CCompte_H

class CCompte
{

};
#endif

#include "CCourant.h"

void CCourant::setSolde(float val)
{

	sol=val;

}

float CCourant::getSolde()
{
return sol;
}

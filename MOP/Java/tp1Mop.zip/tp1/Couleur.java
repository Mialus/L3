public enum Couleur {
	PIQUE, TREFLE, COEUR, CARREAU
}

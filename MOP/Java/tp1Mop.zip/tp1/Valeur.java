public enum Valeur {
	SEPT, HUIT, NEUF, DIX, VALET, DAME, ROI, AS
}

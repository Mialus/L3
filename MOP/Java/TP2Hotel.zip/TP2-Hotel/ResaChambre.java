public class ResaChambre{
	private LinkedList<Chambre> listeChambreLibres=new LinkedList();
	
	ResaChambre(Hotel h) {
	Iterator<Chambre>  i=h.getIterator();
	while (i.hasNext()) {
	
	}
	}
	
}
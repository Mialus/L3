import java.til.*;

public class main {
	public static void main(String args[]){
			Chambre c1 = new ChambreSimple(1,1,105,false);
			Chambre c2 = new ChambreSimple(1,2,203,true);
			Chambre c3 = new ChambreSimple(2,3,325,true);
			Chambre c4 = new ChambreSimple(2,1,127,false);
	}
	
	System.out.println(c1);
	System.out.println(c2);
	System.out.println(c3);
	System.out.println(c4);
		
}